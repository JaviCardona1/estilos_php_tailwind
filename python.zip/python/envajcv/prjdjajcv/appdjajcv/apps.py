from django.apps import AppConfig


class AppdjajcvConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appdjajcv'
